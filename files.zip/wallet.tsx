/**
 * WalletScreen — شاشة المحفظة: بطاقة الرصيد وسجل الحركات.
 * تعتمد على hook useWallet للتحديث اللحظي والترقيم اللا نهائي.
 */
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, View } from "react-native";
import { AppText, EmptyState, Screen } from "@/components/ui";
import { TransactionRow, WalletBalanceCard } from "@/components/wallet";
import { useWallet } from "@/hooks/useWallet";
import { colors, fontSize, spacing } from "@/constants/theme";
import type { WalletTransaction } from "@/types/database";

export default function WalletScreen() {
  const { balance, transactions, loading, refreshing, refresh, loadMore } = useWallet();

  const renderHeader = () => (
    <View style={styles.header}>
      <AppText weight="semibold" style={styles.pageTitle}>
        محفظتي
      </AppText>
      <WalletBalanceCard balance={balance} onTopUp={() => {}} />
      <AppText weight="semibold" style={styles.sectionTitle}>
        آخر الحركات
      </AppText>
    </View>
  );

  if (loading) {
    return (
      <Screen>
        <View style={styles.center}>
          <ActivityIndicator color={colors.gold} />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <FlatList<WalletTransaction>
        data={transactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <TransactionRow tx={item} />}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={<EmptyState icon="receipt-outline" title="لا توجد حركات بعد" />}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        onEndReachedThreshold={0.4}
        onEndReached={loadMore}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.gold} />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xxl },
  header: { paddingTop: spacing.md },
  pageTitle: { fontSize: fontSize.xl, marginBottom: spacing.md },
  sectionTitle: { fontSize: fontSize.base, marginTop: spacing.lg, marginBottom: spacing.xs },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
});
