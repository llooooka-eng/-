/**
 * التخطيط الجذري لتطبيق تأنق:
 * - يفرض اتجاه RTL (يحتاج إعادة تشغيل مرة واحدة عند أول إقلاع).
 * - يحمّل خطوط IBM Plex Sans Arabic قبل إظهار الواجهة.
 * - يلفّ التطبيق بـ AuthProvider و SafeAreaProvider.
 */
import { useEffect } from "react";
import { I18nManager } from "react-native";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import {
  IBMPlexSansArabic_400Regular,
  IBMPlexSansArabic_500Medium,
  IBMPlexSansArabic_600SemiBold,
  useFonts,
} from "@expo-google-fonts/ibm-plex-sans-arabic";
import { AuthProvider } from "@/context/AuthContext";
import { colors } from "@/constants/theme";

// افرض RTL مرة واحدة (يتطلب إعادة تشغيل التطبيق ليأخذ مفعوله كاملاً)
if (!I18nManager.isRTL) {
  I18nManager.allowRTL(true);
  I18nManager.forceRTL(true);
}

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    IBMPlexSansArabic_400Regular,
    IBMPlexSansArabic_500Medium,
    IBMPlexSansArabic_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded) SplashScreen.hideAsync();
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <SafeAreaProvider>
      <AuthProvider>
        <StatusBar style="dark" />
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.pearl } }}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="booking/confirm" options={{ presentation: "card" }} />
        </Stack>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
