/**
 * مكوّنات واجهة أساسية مشتركة، مبنية على نظام تصميم تأنق.
 */
import type { PropsWithChildren, ReactNode } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  type TextProps,
  View,
  type ViewStyle,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { colors, fontFamily, fontSize, radius, spacing } from "@/constants/theme";

/** حاوية شاشة بخلفية لؤلؤية وحواف آمنة */
export function Screen({ children, style }: PropsWithChildren<{ style?: ViewStyle }>) {
  return (
    <SafeAreaView style={[styles.screen, style]} edges={["top"]}>
      {children}
    </SafeAreaView>
  );
}

/** نص افتراضي بخط IBM Plex Sans Arabic */
export function AppText({ style, weight = "regular", ...rest }: TextProps & { weight?: keyof typeof fontFamily }) {
  return <Text {...rest} style={[{ fontFamily: fontFamily[weight], color: colors.textPrimary }, style]} />;
}

/** بطاقة بيضاء بحواف ناعمة */
export function Card({ children, style }: PropsWithChildren<{ style?: ViewStyle }>) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Divider() {
  return <View style={styles.divider} />;
}

type ButtonVariant = "primary" | "dark" | "outline";

/** زر بثلاثة أنماط: ذهبي (primary) / حبري (dark) / محدّد (outline) */
export function Button({
  title,
  onPress,
  variant = "primary",
  loading = false,
  disabled = false,
  icon,
}: {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  loading?: boolean;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
}) {
  const isDisabled = disabled || loading;
  const palette: Record<ButtonVariant, { bg: string; fg: string; border: string }> = {
    primary: { bg: colors.gold, fg: colors.ink, border: colors.gold },
    dark: { bg: colors.ink, fg: colors.white, border: colors.ink },
    outline: { bg: "transparent", fg: colors.textPrimary, border: colors.border },
  };
  const c = palette[variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: c.bg, borderColor: c.border, opacity: isDisabled ? 0.5 : pressed ? 0.85 : 1 },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={c.fg} />
      ) : (
        <View style={styles.buttonInner}>
          {icon ? <Ionicons name={icon} size={18} color={c.fg} /> : null}
          <Text style={[styles.buttonText, { color: c.fg }]}>{title}</Text>
        </View>
      )}
    </Pressable>
  );
}

/** دائرة أيقونة ملوّنة */
export function IconBadge({
  name,
  bg,
  color,
  size = 38,
}: {
  name: keyof typeof Ionicons.glyphMap;
  bg: string;
  color: string;
  size?: number;
}) {
  return (
    <View style={[styles.iconBadge, { width: size, height: size, backgroundColor: bg }]}>
      <Ionicons name={name} size={Math.round(size * 0.5)} color={color} />
    </View>
  );
}

/** حالة فارغة عامة */
export function EmptyState({ icon, title }: { icon: keyof typeof Ionicons.glyphMap; title: string }) {
  return (
    <View style={styles.empty}>
      <Ionicons name={icon} size={40} color={colors.textMuted} />
      <AppText style={{ color: colors.textSecondary, marginTop: spacing.sm }}>{title}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.pearl },
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 0.5,
    borderColor: colors.border,
    padding: spacing.lg,
  },
  divider: { height: 0.5, backgroundColor: colors.borderSoft, marginVertical: spacing.md },
  button: {
    borderRadius: radius.md,
    borderWidth: 1,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonInner: { flexDirection: "row", alignItems: "center", gap: 8 },
  buttonText: { fontFamily: fontFamily.semibold, fontSize: fontSize.lg },
  iconBadge: { borderRadius: radius.md, alignItems: "center", justifyContent: "center" },
  empty: { alignItems: "center", justifyContent: "center", paddingVertical: spacing.xxl * 2 },
});
